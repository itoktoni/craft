<?php

return [

    'system' => 'Application',
];
